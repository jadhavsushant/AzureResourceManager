﻿Param(

    [string] $settingsFileName = '\Settings\DbFWInputSettings.json',
    [string] $armDeploymentTemplateFile = '\Templates\DbFWArmTemplate.json',
    [boolean] $unitTestMode = $false
)

#Check no missing setting
function Test-ParameterSet {
    param
    (
        [parameter(Mandatory = $true)][System.Object]$settings
    )
    # Loop through the $settings and check no missing setting
    if ($null -eq $applicationFileJson.subscriptions) { throw "Missing subscriptions field in settings file" }             
    foreach ($subscription in $applicationFileJson.subscriptions) {
        if ($null -eq $subscription.subscriptionId) { throw "Missing subscription Id field in settings file" }
        # Loop through the $settings and check no missing setting
        foreach ($vault in $settings.WorkLoads) {
            if ($null -eq $vault.applicationName) { throw "Missing applicationNam in settings file for $($subscription.subscriptionId)" }
            if ($null -eq $vault.environmentName) { throw "Missing environmentName in settings file for $($subscription.subscriptionId)" }
            if ($null -eq $vault.resourceGroupName) { throw "Missing resourceGroupName in settings file for $($subscription.subscriptionId)" }
            if ($null -eq $vault.DbName) { throw "Missing Resource name in settings file for $($subscription.subscriptionId)" }
            if ($null -eq $vault.DbType) { throw "Missing Database Type in settings file for $($subscription.subscriptionId)" }
            elseif ($vault.DbType -eq "Cosmos") {
                if ($null -eq $vault.'cosmosDB-IP/CIDR-range') { throw "Missing cosmosDB-IP/CIDR-range in settings file for $($subscription.subscriptionId)" }
            }
            else {
                # if ($null -eq $vault.ruleName) { throw "Missing Rule Name in settings file for $($subscription.subscriptionId)" }
                # if ($null -eq $vault.'SQL-MySQL-endIPAddress') { throw "Missing SQL-MySQL-endIPAddress in settings file for $($subscription.subscriptionId)" }
                # if ($null -eq $vault.'SQL-MySQL-startIPAddress') { throw "Missing SQL-MySQL-startIPAddress in settings file for $($subscription.subscriptionId)" }
                if ($null -eq $vault.'SQLfirewallIPAddresses') { throw "Missing SQLfirewallIPAddresses in settings file for $($subscription.subscriptionId)" }
            }

            
        } # Virtual Network
    } # Subscription
    return $true
} #

#Deploy network
function Update-firewallRule {
    [CmdletBinding(
        SupportsShouldProcess = $true,
        ConfirmImpact = 'Low'
    )]
    [OutputType([String])]
    param
    (
        [parameter(Mandatory = $true)][string]$armDeploymentTemplateFile,
        [parameter(Mandatory = $true)][string]$settingsFileName,
        [parameter(Mandatory = $true)][string]$resourceGroupName,
        [parameter(Mandatory = $true)][int]$loadcount
        
    )
    if ($PSCmdlet.ShouldProcess($resourceGroupName)) {   
        #Check resource group exist
        try {
            $resourceGroup = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction Stop   
        }
        catch {
            $resourceGroup = $null
        }
        if ($null -eq $resourceGroup) {
            $message = "Resource group $resourceGroupName not found, deployment stop"
            Write-Verbose $message
            return $message
        }
        else {
            # Prepare deployment variables
            Write-Verbose "ResourceGroup Found "
            $parameters = Get-JsonParameterSet -settingsFileName $settingsFileName
            
            $DbName = $parameters.WorkLoads[$loadcount].DbName
            $DbType = $parameters.WorkLoads[$loadcount].DbType
            # this block will execute if the parameter is set to DBtype -eq "Cosmos"
            if ($DbType -eq "Cosmos") {
                #connect to existing database and add to array
                #collect the database existing firewall IPs
                $listout_existing_ips = @()
                $connect_to_db = Get-AzCosmosDBAccount -ResourceGroupName $parameters.WorkLoads[$loadcount].resourceGroupName -Name $parameters.WorkLoads[$loadcount].DbName
                $present_dbIPs = $connect_to_db.IpRules | Select-Object -ExpandProperty IpAddressOrRangeProperty
                $listout_existing_ips += $present_dbIPs
                $new_cosmos_DBIP = $parameters.WorkLoads[$loadcount].'cosmosDB-IP/CIDR-range'
                $listout_existing_ips += $new_cosmos_DBIP
                $cosmosDBIP = $listout_existing_ips| ForEach-Object {
                    @{
                        'ipAddressOrRange' = [string]$_
                    }
                }
            }
            else {
                # $startIP = "$($parameters.WorkLoads[$loadcount].'SQL-MySQL-startIPAddress')"
                # $endIP = "$($parameters.WorkLoads[$loadcount].'SQL-MySQL-endIPAddress')"
                # $ruleName = "$($parameters.WorkLoads[$loadcount].ruleName)"
                # $IPAddress = "$($parameters.WorkLoads[$loadcount].'SQLfirewallIPAddresses')"
                # $endIP = "$($parameters.WorkLoads[$loadcount].'SQL-MySQL-endIPAddress')"
                # $ruleName = "$($parameters.WorkLoads[$loadcount].ruleName)"
                # $hash_sql_ips = @{}
                $str_sql_ips = $parameters.WorkLoads[$loadcount].SQLfirewallIPAddresses | ForEach-Object { 
                    @{'RuleName' =[string]$_.Rulename; 'startIpAddress' = [string]$_.startIP; 'endIpAddress' = [string]$_.endip  }    
                    }
            }
            # $hash_sql_ips.Add("SQLfirewallIPAddresses", $str_sql_ips)

            $ParameterSet = @{ }
            $ParameterSet.Add('DbType', $DbType)
            $ParameterSet.Add('DbName', $DbName)
            if ($DbType -eq "Cosmos") { $ParameterSet.Add('cosmosDB-IP/CIDR-range', $cosmosDBIP) }
            else {
                $ParameterSet.Add('SQLfirewallIPAddresses', $str_sql_ips)
                # $ParameterSet.Add('SQL-MySQL-startIPAddress', $startIP) 
                # $ParameterSet.Add('SQL-MySQL-endIPAddress', $endIP) 
                # $ParameterSet.Add('ruleName', $ruleName)
                # $ParameterSet.Add('SQLfirewallIPAddresses', $IPAddress)
                # $ParameterSet.Add('SQL-MySQL-endIPAddress', $endIP) 
                # $ParameterSet.Add('ruleName', $ruleName)
               
            }  

            $deploymentParameters = $ParameterSet
        }
        # Unlock ResourceGroup
        Unlock-ResourceGroup $resourceGroupName
        write-verbose "ResourceGroup Unlocked"

        #Deploy the infrastructure
        Write-Verbose "Firewall update template File path: $armDeploymentTemplateFile"    
        $armDeployment = New-AzResourceGroupDeployment -Name ((Get-ChildItem $armDeploymentTemplateFile).BaseName + '-' + ((Get-Date).ToUniversalTime()).ToString('yyyyMMdd-HHmm')) `
            -ResourceGroupName $resourceGroupName `
            -TemplateFile $armDeploymentTemplateFile `
            -TemplateParameterObject $deploymentParameters `
            -Force -Verbose

        Lock-ResourceGroup $resourceGroupName
        Write-Verbose "ResourceGroup Locked"

        Write-Verbose "Deployment on rg $($armDeployment.ResourceGroupName) $($armDeployment.ProvisioningState) $($armDeployment.Timestamp)"
        return $armDeployment.ProvisioningState
		
		
    }
}

function Publish-Infrastructure {
    param(
        [parameter(Mandatory = $true)][string]$settingsFileName,
        [parameter(Mandatory = $true)][string]$armDeploymentTemplateFile
        
    )
 
    $settings = Get-JsonParameterSet -settingsFileName $settingsFileName
    $deploymentIsSucceeded = $true
    $workloadCount = $settings.WorkLoads.Count
    Write-Verbose "workloadCounts: $workloadCount"
    if ($workloadCount -ge 1) {
        for ($i = 0; $i -lt $workloadCount; $i++) { 
            $applicationName = $settings.WorkLoads[$i].applicationName
            $environmentName = $settings.WorkLoads[$i].environmentName

            $applicationFile = "..\SettingsByWorkload\" + "nv_" + $applicationName + ".workload.json"              
            $applicationFile = Get-FileFullPath -fileName $applicationFile  -rootPath $PSScriptRoot               
            $applicationFileJson = Get-JsonParameterSet -settingsFileName $applicationFile
            $null = Test-ParameterSet -settings $settings
            #                $organizationName = $applicationFileJson.organizationName
            $policyCount = $applicationFileJson.subscriptions.Count
            if ($policyCount -ge 1) {  
                for ($j = 0; $j -lt $policyCount; $j++) { 
                    if (($applicationFileJson.subscriptions[$j].environmentName -eq $environmentName) -and ($applicationFileJson.subscriptions[$j].applicationName -eq $applicationName)) {
                        $subscriptionId = $applicationFileJson.subscriptions[$j].subscriptionId 
                        Write-Verbose "Environment Subscription: $($subscriptionId)"
                        Set-ContextIfNeeded -SubscriptionId $subscriptionId
                        $resourceGroupName = $settings.WorkLoads[$i].resourceGroupName

                        Write-Verbose "Ready to start update on environment $EnvironmentName for firewall rule in subscription $subscriptionId for resource group: $resourceGroupName"
                
                        $result = Update-firewallRule `
                            -armDeploymentTemplateFile $armDeploymentTemplateFile `
                            -settingsFileName $settingsFileName `
                            -resourceGroupName $resourceGroupName `
                            -loadcount $i
							
                        if ($result -ne 'Succeeded') { $deploymentIsSucceeded = $false }
                            
                    }
                    else { Write-Verbose "$applicationName Application don't have valid Subscription" }
                }
            }
        }
    }
    if ($deploymentIsSucceeded -eq $false) {
        $errorID = 'Deployment failure'
        $errorCategory = [System.Management.Automation.ErrorCategory]::LimitsExceeded
        $errorMessage = 'Deployment failed'
        $exception = New-Object -TypeName System.SystemException -ArgumentList $errorMessage
        $errorRecord = New-Object -TypeName System.Management.Automation.ErrorRecord -ArgumentList $exception, $errorID, $errorCategory, $null
        Throw $errorRecord
    }
    else {
        return $true    
    } # Deploy status
} # function


#END OF FUNCTIONS, START OF SCRIPT
if ($unitTestMode) {
    #do nothing
    Write-Verbose 'Unit test mode, no deployment' -Verbose
}
else {
    #Log in Azure if not already done
    try {
        $azureRmContext = Get-AzContext -ErrorAction Stop
    }
    catch {
        $result = Add-AzAccount
        $azureRmContext = $result.Context
    }
    Write-Verbose "Subscription name $($azureRmContext.Subscription.Name)" -Verbose
    $VerbosePreference = 'Continue'

    # Get required templates and setting files. Throw if not found
    $scriptsPath = $PSScriptRoot
    for ($i = 1; $i -lt 2 ; $i++) { $scriptsPath = Split-Path -Path $scriptsPath -Parent }  
    $SettingsPath = Join-Path $scriptsPath $settingsFileName
    $settingsFileName = $SettingsPath
    $ARMTemplatePath = Join-Path $scriptsPath $armDeploymentTemplateFile
    $armDeploymentTemplateFile = $ARMTemplatePath
    #$SettingsByWorkload = Get-FileFullPath -fileName $SettingsByWorkload -rootPath $PSScriptRoot

    # Deploy infrastructure
    return Publish-Infrastructure `
        -settingsFileName $settingsFileName `
        -armDeploymentTemplateFile $armDeploymentTemplateFile `
        #       -targetEnvironment $targetDeploymentRing `
        #      -SettingsByWorkloadParam $SettingsByWorkload
}
# END of script